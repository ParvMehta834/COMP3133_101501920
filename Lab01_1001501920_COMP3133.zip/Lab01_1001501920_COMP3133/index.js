const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");

const inputFile = path.join(__dirname, "input_countries.csv");
const canadaFile = path.join(__dirname, "canada.txt");
const usaFile = path.join(__dirname, "usa.txt");

[canadaFile, usaFile].forEach((file) => {
  if (fs.existsSync(file)) {
    fs.unlinkSync(file);
    console.log(`Deleted: ${path.basename(file)}`);
  }
});

const canadaStream = fs.createWriteStream(canadaFile, { flags: "a" });
const usaStream = fs.createWriteStream(usaFile, { flags: "a" });

const header = "country,year,population\n";
canadaStream.write(header);
usaStream.write(header);

fs.createReadStream(inputFile)
  .pipe(csv())
  .on("data", (row) => {
    const country = (row.country || "").trim();

    const line = `${country.toLowerCase()},${row.year},${row.population}\n`;

    if (country === "Canada") {
      canadaStream.write(line);
    } else if (country === "United States") {
      usaStream.write(line);
    }
  })
  .on("end", () => {
    canadaStream.end();
    usaStream.end();
    console.log("Done ✅ Created canada.txt and usa.txt");
  })
  .on("error", (err) => {
    console.error("Error reading CSV:", err.message);
  });
